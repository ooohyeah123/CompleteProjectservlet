package com.capgemini.web.ars.util;

import java.sql.Connection;


import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;


public class DbUtil 
{
	public static Connection getConnection() throws NamingException, SQLException
	{
		final Logger myLogger = Logger.getLogger(DbUtil.class);
		InitialContext context = new InitialContext();
		DataSource ds =  (DataSource) context.lookup("java:/myDS");
		
		myLogger.info("connection established");
		return ds.getConnection();
	}
}
