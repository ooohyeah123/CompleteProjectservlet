package com.capgemini.web.ars.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;

import com.capgemini.web.ars.bean.Airport;
import com.capgemini.web.ars.bean.BookingInformation;
import com.capgemini.web.ars.bean.FlightInformation;
import com.capgemini.web.ars.exception.ARSException;
import com.sun.glass.ui.Application;

public interface IAirlineReservationService 
{
	public void addAirport(Airport ap) throws ARSException; //not used
	public void addFlightInformation(FlightInformation flightInfo) throws ARSException;
	public int addBookingInformation(BookingInformation bookingEntry) throws ARSException;
	public ArrayList <FlightInformation> showOnDate(Date date) throws ARSException; //not used
	public ArrayList<FlightInformation> viewFlightBtw(String depArp , String arrArp ) throws ARSException; //not used
	public ArrayList<FlightInformation> viewFlightOn(String depArp , String arrArp , Date date) throws ARSException;
	public ArrayList <FlightInformation> showAllFlights() throws ARSException;
	public FlightInformation viewFlightDetail(int flightNo) throws ARSException;
	public ArrayList<BookingInformation> viewBookings(int flightNo) throws ARSException; //not used
	public  HashMap<String, Airport> getAirportList() throws ARSException;
	public void updateFlightInformation(FlightInformation updateflight) throws ARSException;
	public void removeFlightInformation( int flightNo ) throws ARSException; 
	public BookingInformation getBooking(int bookId) throws ARSException;
	public void removeBooking(int bookId,  String classType , int seats , int flightNo) throws ARSException;
}
