package com.capgemini.web.ars.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;

import com.capgemini.web.ars.bean.Airport;
import com.capgemini.web.ars.bean.BookingInformation;
import com.capgemini.web.ars.bean.FlightInformation;
import com.capgemini.web.ars.dao.AirlineReservationDaoImpl;
import com.capgemini.web.ars.dao.IAirlineReservationDao;
import com.capgemini.web.ars.exception.ARSException;

public class AirlineReservationServiceImpl implements IAirlineReservationService
{
	IAirlineReservationDao daoObj;
	
	public AirlineReservationServiceImpl() 
	{
		daoObj = new AirlineReservationDaoImpl();
	}

	@Override
	public void addAirport(Airport ap) throws ARSException 
	{
		daoObj.addAirport(ap);		
	}

	@Override
	public void addFlightInformation(FlightInformation flightInfo) throws ARSException
	{
		daoObj.addFlightInformation(flightInfo);
	}

	@Override
	public int addBookingInformation(BookingInformation bookingEntry) throws ARSException 
	{
		return daoObj.addBookingInformation(bookingEntry);
	}

	@Override
	public ArrayList<FlightInformation> showOnDate(Date date) throws ARSException 
	{
		return daoObj.showOnDate(date);
	}

	@Override
	public ArrayList<FlightInformation> viewFlightBtw(String depArp, String arrArp) throws ARSException 
	{
		return daoObj.viewFlightBtw(depArp, arrArp);
	}

	@Override
	public ArrayList<BookingInformation> viewBookings(int flightNo) throws ARSException 
	{
		return daoObj.viewBookings(flightNo);
	}

	@Override
	public FlightInformation viewFlightDetail(int flightNo) throws ARSException 
	{
		return daoObj.viewFlightDetail(flightNo);
	}

	@Override
	public  HashMap<String, Airport> getAirportList() throws ARSException
	{
		return daoObj.getAirportList();
	}

	@Override
	public ArrayList<FlightInformation> viewFlightOn(String depArp,
			String arrArp, Date date) throws ARSException
	{
		return daoObj.viewFlightOn(depArp,arrArp,date) ;
	}

	@Override
	public ArrayList<FlightInformation> showAllFlights()throws ARSException
	{
		return daoObj.showAllFlights();
	}

	@Override
	public void updateFlightInformation(FlightInformation updateflight) throws ARSException
	{
		daoObj.updateFlightInformation(updateflight);
	}

	@Override
	public void removeFlightInformation(int flightNo)throws ARSException
	{
		daoObj. removeFlightInformation(flightNo);
	}

	@Override
	public BookingInformation getBooking(int bookId)throws ARSException
	{
		return daoObj.getBooking(bookId);
	}

	@Override
	public void removeBooking(int bookId,  String classType , int seats, int flightNo) throws ARSException
	{
		daoObj.removeBooking(bookId,classType,seats,flightNo);
	}

}
