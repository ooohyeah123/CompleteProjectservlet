package com.capgemini.web.ars.bean;

public class Airport 
{
	private String airportName;
	private String abbreviation;
	private String city;
	private String state;
	private String country;
	
	public Airport() 
	{
		super();
	}

	public Airport(String airportName, String abbreviation, String city,
			String state, String country) 
	{
		super();
		this.airportName = airportName;
		this.abbreviation = abbreviation;
		this.city = city;
		this.state = state;
		this.country = country;
	}

	public String getAirportName() {
		return airportName;
	}

	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}

	public String getAbbreviation() {
		return abbreviation;
	}

	public void setAbbreviation(String abbreviation) {
		this.abbreviation = abbreviation;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	public String toString() {
		return "Airport [airportName=" + airportName + ", abbreviation="
				+ abbreviation + ", city=" + city + ", state=" + state
				+ ", country=" + country + "]";
	}
	
	
	
	
	
}
